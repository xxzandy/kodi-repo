"""Playback: fresh preview-API resolve at play time + ListItem construction.

Manifest URLs carry short-lived Akamai `hdnts` tokens, so we ALWAYS resolve
at the moment of playback and never cache stream URLs.

Live TV engine options (setting `live_engine`):
  0 = InputStream Adaptive on the preview-API manifest (the stream web Areena
      plays: multiaudio fi/sv + DVR window) with live-edge tuning. Default.
  1 = inputstream.ffmpegdirect (IPTV-proven fallback for ISA live-HLS stalls)
  2 = Kodi core player (raw m3u8, no inputstream addon)
"""
import json
import time
from urllib.parse import urlencode

import xbmcgui
import xbmcplugin

from resources.lib import addon

USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")

ENGINE_ISA = 0
ENGINE_FFMPEGDIRECT = 1
ENGINE_KODI = 2


def play(handle: int, params: dict) -> None:
    pid = params.get("id", "")
    kind = params.get("kind", "vod")     # vod | live | audio
    client = addon.build_client()

    stream = client.get_stream(pid)
    if stream.status == "not_allowed":
        # The yletest probes showed not_allowed can be transient; retry once.
        addon.log(f"{pid}: not_allowed, retrying once")
        time.sleep(2)
        stream = client.get_stream(pid)

    if stream.status == "pending":
        _fail(handle, addon.localized(30210))   # not yet available
        return
    if stream.status == "expired":
        _fail(handle, addon.localized(30211))   # no longer available
        return
    if stream.status == "not_allowed":
        _fail(handle, addon.localized(30212))   # not viewable in your region
        return
    if not stream.is_playable:
        addon.log_error(f"{pid}: unplayable, status={stream.status} raw keys="
                        f"{sorted(stream.raw.keys())}")
        _fail(handle, addon.localized(30213))   # could not resolve stream
        return

    if stream.is_audio or kind == "audio":
        li = _audio_listitem(stream)
    elif stream.is_live or kind == "live":
        li = _live_listitem(stream, client)
    else:
        li = _vod_listitem(stream, client)

    addon.log(f"playing {pid}: status={stream.status} media_id={stream.media_id} "
              f"url={ (stream.play_url or '')[:120] }")
    xbmcplugin.setResolvedUrl(handle, True, li)


# --------------------------------------------------------------------- #
# ListItem builders per kind
# --------------------------------------------------------------------- #
def _base_listitem(stream) -> xbmcgui.ListItem:
    li = xbmcgui.ListItem(path=stream.play_url, offscreen=True)
    tag = li.getVideoInfoTag()
    tag.setMediaType("video")
    if stream.title:
        tag.setTitle(stream.title)
    if stream.description:
        tag.setPlot(stream.description)
    if stream.duration_seconds:
        tag.setDuration(int(stream.duration_seconds))
    if stream.age_restriction:
        tag.setMpaa(f"K-{stream.age_restriction}")
    if stream.image_id:
        from resources.lib.yle_areena import images
        li.setArt({
            "thumb": images.thumb_url(stream.image_id, stream.image_version),
            "fanart": images.fanart_url(stream.image_id, stream.image_version),
        })
    return li


def _spoof_headers(client) -> str:
    headers = {"User-Agent": USER_AGENT}
    headers.update(client.manifest_headers())   # X-Forwarded-For only if enabled
    return urlencode(headers)


def _vod_listitem(stream, client) -> xbmcgui.ListItem:
    li = _base_listitem(stream)
    li.setMimeType("application/x-mpegurl")
    li.setContentLookup(False)
    li.setProperty("inputstream", "inputstream.adaptive")
    header_blob = _spoof_headers(client)
    li.setProperty("inputstream.adaptive.manifest_headers", header_blob)
    li.setProperty("inputstream.adaptive.stream_headers", header_blob)
    subs = [s.url for s in stream.subtitles if s.url]
    if subs:
        li.setSubtitles(subs)
    return li


def _live_listitem(stream, client) -> xbmcgui.ListItem:
    engine = addon.get_int("live_engine", ENGINE_ISA)
    li = _base_listitem(stream)
    li.setProperty("IsPlayable", "true")

    if engine == ENGINE_FFMPEGDIRECT:
        li.setMimeType("application/x-mpegurl")
        li.setContentLookup(False)
        li.setProperty("inputstream", "inputstream.ffmpegdirect")
        li.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
        li.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
        li.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
    elif engine == ENGINE_KODI:
        # Raw manifest straight to the core ffmpeg player: no properties at all.
        li.setMimeType("application/x-mpegurl")
        li.setContentLookup(False)
    else:
        li.setMimeType("application/x-mpegurl")
        li.setContentLookup(False)
        li.setProperty("inputstream", "inputstream.adaptive")
        header_blob = _spoof_headers(client)
        li.setProperty("inputstream.adaptive.manifest_headers", header_blob)
        li.setProperty("inputstream.adaptive.stream_headers", header_blob)
        delay = addon.get_int("live_delay", 24)
        li.setProperty("inputstream.adaptive.live_delay", str(delay))
        li.setProperty("inputstream.adaptive.manifest_config",
                       json.dumps({"hls_ignore_endlist": True}))
    return li


def _audio_listitem(stream) -> xbmcgui.ListItem:
    li = xbmcgui.ListItem(path=stream.play_url, offscreen=True)
    tag = li.getMusicInfoTag()
    if stream.title:
        tag.setTitle(stream.title)
    tag.setArtist("Yle")
    if stream.duration_seconds:
        tag.setDuration(int(stream.duration_seconds))
    if stream.image_id:
        from resources.lib.yle_areena import images
        li.setArt({
            "thumb": images.thumb_url(stream.image_id, stream.image_version),
            "fanart": images.fanart_url(stream.image_id, stream.image_version),
        })
    if not stream.is_audio or not stream.media_url:
        # audio HLS (live radio): core ffmpeg player handles it natively
        li.setMimeType("application/x-mpegurl")
        li.setContentLookup(False)
    return li


def _fail(handle: int, message: str) -> None:
    xbmcgui.Dialog().notification(addon.ADDON_NAME, message,
                                  xbmcgui.NOTIFICATION_WARNING, 5000)
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))
