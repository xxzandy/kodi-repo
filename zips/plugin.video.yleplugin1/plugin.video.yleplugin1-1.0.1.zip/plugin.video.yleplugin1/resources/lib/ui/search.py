"""Search UI with per-service (tv / radio) history."""
import xbmcgui
import xbmcplugin

from resources.lib import addon, search_history
from resources.lib.ui import items
from resources.lib.ui.catalog import _render_cards


def search_menu(handle: int, params: dict) -> None:
    service = params.get("service", "tv")
    entries = [items.folder_item(f"[B]{addon.localized(30130)}[/B]",
                                 action="search_new", service=service)]
    for query in search_history.entries(service):
        url, li, is_folder = items.folder_item(
            query, action="search_results", query=query, service=service)
        li.addContextMenuItems([(
            addon.localized(30131),   # Remove from history
            "RunPlugin(" + items.plugin_url(action="search_remove",
                                            query=query, service=service) + ")",
        )])
        entries.append((url, li, is_folder))
    xbmcplugin.setContent(handle, "videos")
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def search_new(handle: int, params: dict) -> None:
    service = params.get("service", "tv")
    query = xbmcgui.Dialog().input(addon.localized(30103))
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    search_history.add(query, service)
    params = dict(params, query=query)
    search_results(handle, params)


def search_results(handle: int, params: dict) -> None:
    service = params.get("service", "tv")
    query = params["query"]
    offset = int(params.get("offset", 0))
    client = addon.build_client()
    page = client.search(query, offset=offset, service=service)
    container = "episodes" if service == "radio" else None
    _render_cards(handle, page, params, container=container,
                  action="search_results", query=query, service=service)


def search_remove(handle: int, params: dict) -> None:
    search_history.remove(params.get("query", ""), params.get("service", "tv"))
    import xbmc
    xbmc.executebuiltin("Container.Refresh")
