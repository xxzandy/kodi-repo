"""Live TV: linear channels with now/next EPG + live events from /suorat."""
from datetime import datetime

import xbmcplugin

from resources.lib import addon, cache
from resources.lib.ui import items


def live_menu(handle: int, params: dict) -> None:
    client = addon.build_client()

    def fetch():
        result = []
        for ch in client.live_channels():
            entry = {"name": ch["name"], "program_id": ch["program_id"], "now_next": ""}
            try:
                stream = client.get_stream(ch["program_id"])
                entry["now_next"] = _now_next_text(stream.schedule)
            except Exception as e:  # noqa: BLE001 - EPG is best-effort
                addon.log(f"EPG fetch failed for {ch['program_id']}: {e}")
            result.append(entry)
        return result

    channels, _ = cache.get_or_fetch("live_epg", 300, fetch)

    entries = [
        items.live_channel_item(ch["name"], ch["program_id"], ch["now_next"])
        for ch in channels
    ]
    entries.append(items.folder_item(addon.localized(30110), action="live_events"))
    xbmcplugin.setContent(handle, "videos")
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def live_events(handle: int, params: dict) -> None:
    """Rows of areena.yle.fi/suorat, scraped fresh (pre-signed tokens current)."""
    client = addon.build_client()

    def fetch():
        view = client.live_events_rows()
        return [{"title": r.title, "source_uri": r.source_uri}
                for r in view.rows if r.source_uri and r.title]

    rows, _ = cache.get_or_fetch("suorat_rows", 300, fetch)
    entries = [
        items.folder_item(r["title"], action="row", uri=r["source_uri"], title=r["title"])
        for r in rows
    ]
    xbmcplugin.setContent(handle, "videos")
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def _now_next_text(schedule) -> str:
    """'Now: X (12:00-13:00)\nNext: Y' from a service_schedule entry list."""
    if not schedule:
        return ""
    now = datetime.utcnow().isoformat()
    current_idx = None
    for i, entry in enumerate(schedule):
        start = (entry.start or "")[:19]
        end = (entry.end or "")[:19]
        if start and end and start <= now[:19] <= end:
            current_idx = i
            break
    lines = []
    if current_idx is not None:
        cur = schedule[current_idx]
        lines.append(f"{addon.localized(30111)}: {cur.title or '?'} "
                     f"({_hhmm(cur.start)}–{_hhmm(cur.end)})")
        if current_idx + 1 < len(schedule):
            nxt = schedule[current_idx + 1]
            lines.append(f"{addon.localized(30112)}: {nxt.title or '?'} "
                         f"({_hhmm(nxt.start)})")
    elif schedule:
        first = schedule[0]
        lines.append(f"{addon.localized(30112)}: {first.title or '?'} ({_hhmm(first.start)})")
    return "\n".join(lines)


def _hhmm(iso_ts) -> str:
    if not iso_ts:
        return "?"
    try:
        # ISO timestamps from Yle include offset, e.g. 2026-06-11T18:00:00+03:00
        return datetime.fromisoformat(iso_ts).strftime("%H:%M")
    except ValueError:
        return iso_ts[11:16] if len(iso_ts) >= 16 else "?"
