"""Main menu."""
import xbmcplugin

from resources.lib import addon
from resources.lib.ui import items


def main_menu(handle: int, params: dict) -> None:
    entries = [
        items.folder_item(addon.localized(30100), action="live"),          # Live TV
        items.folder_item(addon.localized(30101), action="view",
                          id="30-3706"),                                   # Front page
        items.folder_item(addon.localized(30102), action="categories"),   # Categories
        items.folder_item(addon.localized(30103), action="search_menu",
                          service="tv"),                                   # Search
        items.folder_item(addon.localized(30104), action="audio"),        # Audio
    ]
    xbmcplugin.setContent(handle, "videos")
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
