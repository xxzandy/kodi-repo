"""Audio: live radio channels + podcast search."""
import xbmcplugin

from resources.lib import addon
from resources.lib.ui import items
from resources.lib.yle_areena import constants as C


def audio_menu(handle: int, params: dict) -> None:
    entries = [
        items.folder_item(addon.localized(30120), action="radio"),         # Live radio
        items.folder_item(addon.localized(30121), action="search_menu",
                          service="radio"),                                # Podcast search
    ]
    xbmcplugin.setContent(handle, "videos")
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)


def radio_channels(handle: int, params: dict) -> None:
    entries = [
        items.radio_channel_item(name, pid)
        for name, pid in C.RADIO_CHANNELS
    ]
    xbmcplugin.setContent(handle, "songs")
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)
