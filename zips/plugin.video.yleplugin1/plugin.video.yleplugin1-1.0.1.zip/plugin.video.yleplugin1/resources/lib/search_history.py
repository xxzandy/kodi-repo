"""Search history persisted as JSON in addon_data, per namespace (tv / radio)."""
import json
import os

from resources.lib import addon

MAX_ENTRIES = 20


def _path() -> str:
    return addon.profile_path("search_history.json")


def _load() -> dict:
    path = _path()
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (ValueError, OSError):
            pass
    return {}


def _save(data: dict) -> None:
    with open(_path(), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)


def entries(namespace: str = "tv") -> list:
    return _load().get(namespace, [])


def add(query: str, namespace: str = "tv") -> None:
    data = _load()
    items = data.get(namespace, [])
    items = [q for q in items if q.lower() != query.lower()]
    items.insert(0, query)
    data[namespace] = items[:MAX_ENTRIES]
    _save(data)


def remove(query: str, namespace: str = "tv") -> None:
    data = _load()
    data[namespace] = [q for q in data.get(namespace, []) if q != query]
    _save(data)


def clear() -> None:
    _save({})
