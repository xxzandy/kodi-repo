"""Tiny JSON file cache in addon_data with TTL + stale fallback.

Used for catalog views, /suorat rows, season lists and live EPG.
NEVER used for preview/stream responses (their hdnts tokens expire in minutes).
"""
import hashlib
import json
import os
import time

from resources.lib import addon


def _path(key: str) -> str:
    digest = hashlib.sha1(key.encode("utf-8")).hexdigest()
    return addon.profile_path("cache", f"{digest}.json")


def get_or_fetch(key: str, ttl_seconds: int, fetch_fn):
    """Return (data, from_stale_fallback).

    Fresh cache hit -> cached data. Miss/expired -> fetch_fn(); on fetch
    failure return the stale entry if one exists (flagged True), else re-raise.
    """
    path = _path(key)
    entry = None
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                entry = json.load(f)
        except (ValueError, OSError):
            entry = None
    if entry and time.time() - entry.get("ts", 0) < ttl_seconds:
        return entry["data"], False

    try:
        data = fetch_fn()
    except Exception:
        if entry is not None:
            addon.log(f"cache: serving stale data for {key}")
            return entry["data"], True
        raise

    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "data": data}, f)
    except OSError as e:
        addon.log(f"cache: write failed: {e}")
    return data, False


def clear() -> int:
    """Delete all cache files; returns how many were removed."""
    cache_dir = os.path.join(addon.PROFILE_DIR, "cache")
    removed = 0
    if os.path.isdir(cache_dir):
        for name in os.listdir(cache_dir):
            try:
                os.remove(os.path.join(cache_dir, name))
                removed += 1
            except OSError:
                pass
    return removed
