"""Build Yle image URLs (thumb / poster / fanart) from a card's image {id, version}.

Yle serves images through a Cloudinary-backed CDN with on-the-fly transforms:

    https://images.cdn.yle.fi/image/upload/<transforms>/v<version>/<image_id>.jpg
"""
from typing import Optional

from .constants import IMAGE_CDN

# Fallback version used when a card omits image.version (from plugin.video.yleareena).
_DEFAULT_VERSION = "1624522786"


def _url(image_id: str, version: Optional[str], transforms: str) -> str:
    version = str(version or _DEFAULT_VERSION)
    return f"{IMAGE_CDN}/{transforms}/v{version}/{image_id}.jpg"


def image_url(image_id: str, version: Optional[str] = None, *, width: int = 640,
              transforms: Optional[str] = None) -> str:
    """16:9 thumbnail URL. `width` is ignored if explicit `transforms` is given."""
    if transforms is None:
        transforms = f"w_{width},ar_16:9,c_fill,dpr_1.0,fl_lossy,f_auto,q_auto,d_yle-elava-arkisto.jpg"
    return _url(image_id, version, transforms)


def thumb_url(image_id: str, version: Optional[str] = None) -> str:
    return image_url(image_id, version, width=640)


def landscape_url(image_id: str, version: Optional[str] = None) -> str:
    return image_url(image_id, version, width=1280)


def poster_url(image_id: str, version: Optional[str] = None) -> str:
    """2:3 poster crop (for skins' poster views)."""
    return _url(image_id, version,
                "w_500,ar_2:3,c_fill,g_auto,fl_lossy,f_auto,q_auto,d_yle-elava-arkisto.jpg")


def fanart_url(image_id: str, version: Optional[str] = None) -> str:
    """Full-bleed 16:9 background image."""
    return _url(image_id, version,
                "w_1920,ar_16:9,c_fill,fl_lossy,f_auto,q_auto,d_yle-elava-arkisto.jpg")
