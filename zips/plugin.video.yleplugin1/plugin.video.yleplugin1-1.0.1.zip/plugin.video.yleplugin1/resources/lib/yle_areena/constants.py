"""Public constants for the Yle Areena APIs.

All keys below are **public client keys** embedded in the Yle Areena web app and the
open-source yle-dl / plugin.video.yleareena tools. They are not secrets; Yle may
rotate or rate-limit them.
"""

# --- API hosts -------------------------------------------------------------
UI_API = "https://areena.api.yle.fi/v1/ui"          # cards, search, content lists
PLAYER_API = "https://player.api.yle.fi/v1/preview"  # program id -> playable manifest
LOCATIONS_API = "https://locations.api.yle.fi/v3/address/current"
AREENA_WEB = "https://areena.yle.fi"                 # SSR pages (__NEXT_DATA__)
IMAGE_CDN = "https://images.cdn.yle.fi/image/upload"  # Cloudinary-backed thumbnails

# --- Public app credentials ------------------------------------------------
# UI / catalog / search / content-list / playlist
AREENA_APP_ID = "areena-web-items"
AREENA_APP_KEY = "wlTs5D9OjIdeS9krPzRQR4I1PYVzoazN"
# Player preview (stream resolution)
PLAYER_APP_ID = "player_static_prod"
PLAYER_APP_KEY = "8930d72170e48303cf5f3867780d549b"

# Common UI-API query params
CLIENT = "yle-areena-web"
API_VERSION = "10"

# Areena server returns 502 for playlist pages larger than 100.
MAX_PAGE_SIZE = 100
DEFAULT_PAGE_SIZE = 30

# --- TV categories (Areena "views"; browse each with client.view(view_id)) --
# Discovered from the "Hae ja selaa" (search & browse) panel on areena.yle.fi/tv.
TV_CATEGORIES = [
    ("Sarjat",                   "57-p8JeXvBA0"),
    ("Elokuvat",                 "57-1BbXLDz6v"),
    ("Dokumentit",               "57-P3dgOa9BO"),
    ("Kulttuuri",                "57-bNogvWVv3"),
    ("Urheilu",                  "57-Nm82dw5J1"),
    ("Uutiset ja ajankohtaiset", "57-1B1zANk3N"),
    ("Lapset",                   "57-P0VW82AxD"),
    ("Videopodcastit",           "30-5145"),
    ("Kuvailutulkatut",          "57-7Dvl8D4eg"),
    ("Viittomakieliset",         "57-bN67eKroa"),
    ("Selkokieliset",            "57-emwn2zm7l"),
    ("Löydä lisää",              "30-5191"),
]
TV_FRONT_PAGE_VIEW = "30-3706"  # the TV front page ("Etusivu")

# Live events / "suorat" SSR page; rows are scraped at runtime so the
# pre-signed source tokens are always fresh (unlike jade's hardcoded JWTs).
SUORAT_PAGE = AREENA_WEB + "/suorat"

# --- Live linear TV channels -------------------------------------------------
# Program ids resolvable via the preview API (the same streams web Areena plays:
# multiaudio fi/sv + DVR window + EPG). Preferred over the direct akamaized URLs.
LIVE_TV_CHANNELS = [
    ("Yle TV1",         "yle-tv1",       "622365", "yletv1fin"),
    ("Yle TV2",         "yle-tv2",       "622366", "yletv2fin"),
    ("Yle Teema & Fem", "yle-teema-fem", "622367", "yletvteemafemfin"),
]
# Direct, clear, un-tokenised HLS fallback (jade's approach; stall-suspect).
LIVE_TV_MANIFEST = "https://yletv.akamaized.net/hls/live/{stream_id}/{stream_name}/index.m3u8"

# --- Live radio channels ------------------------------------------------------
# Preview-API service ids (yle-dl maps Areena's 57-* page ids to these).
# All verified to return ongoing_channel (2026-06-11).
RADIO_CHANNELS = [
    ("Yle Radio 1",                      "yle-radio-1"),
    ("YleX",                             "ylex"),
    ("Yle X3M",                          "yle-x3m"),
    ("Yle Klassinen",                    "yle-klassinen"),
    ("Yle Sámi Radio",                   "yle-sami-radio"),
    ("Yle Radio Suomi (Helsinki)",       "yle-radio-suomi-helsinki"),
    ("Radio Vega (Huvudstadsregionen)",  "radio-vega-huvudstadsregionen"),
]

# Finnish residential (Elisa) range used to spoof X-Forwarded-For so Yle's
# rights engine treats requests as residential. Same trick as yle-dl / jade.
ELISA_IP_NETWORK = "91.152.0.0/13"
