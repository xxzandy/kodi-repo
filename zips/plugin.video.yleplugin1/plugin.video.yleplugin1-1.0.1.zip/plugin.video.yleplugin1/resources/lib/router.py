"""Plugin URL dispatch with a top-level error boundary."""
import traceback
from urllib.parse import parse_qsl

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import addon


def dispatch(argv) -> None:
    handle = int(argv[1])
    params = dict(parse_qsl(argv[2][1:])) if len(argv) > 2 and len(argv[2]) > 1 else {}
    action = params.get("action")

    # Imports inside dispatch keep plugin startup fast for the common path
    # and avoid import cycles.
    from resources.lib.ui import menu, catalog, live, audio, search
    from resources.lib import playback

    routes = {
        None: menu.main_menu,
        "view": catalog.show_view,
        "row": catalog.show_row,
        "series": catalog.show_series,
        "episodes": catalog.show_episodes,
        "categories": catalog.show_categories,
        "search_menu": search.search_menu,
        "search_new": search.search_new,
        "search_results": search.search_results,
        "search_remove": search.search_remove,
        "live": live.live_menu,
        "live_events": live.live_events,
        "audio": audio.audio_menu,
        "radio": audio.radio_channels,
        "play": playback.play,
        "clear_cache": _clear_cache,
    }

    handler = routes.get(action)
    if handler is None:
        addon.log_error(f"unknown action: {action!r}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    try:
        handler(handle, params)
    except Exception as e:  # noqa: BLE001 - top-level boundary
        from resources.lib.yle_areena import YleAreenaError, LayoutChangedError

        addon.log_error(f"action {action!r} failed: {e}\n{traceback.format_exc()}")
        if isinstance(e, LayoutChangedError):
            message = addon.localized(30201)   # "Areena layout changed..."
        elif isinstance(e, YleAreenaError):
            message = str(e)
        else:
            message = addon.localized(30202)   # "Something went wrong..."
        xbmcgui.Dialog().notification(addon.ADDON_NAME, message,
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        if action == "play":
            import xbmcgui as _g
            xbmcplugin.setResolvedUrl(handle, False, _g.ListItem(offscreen=True))
        else:
            xbmcplugin.endOfDirectory(handle, succeeded=False)


def _clear_cache(handle, params) -> None:
    from resources.lib import cache, search_history

    removed = cache.clear()
    if params.get("history") == "1":
        search_history.clear()
    xbmcgui.Dialog().notification(addon.ADDON_NAME,
                                  addon.localized(30203).format(removed),
                                  xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")
