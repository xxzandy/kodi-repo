import sys

from resources.lib.router import dispatch

if __name__ == "__main__":
    dispatch(sys.argv)
