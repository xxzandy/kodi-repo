"""Catalog browsing: categories -> views -> rows -> cards; series -> episodes."""
import xbmcplugin

from resources.lib import addon, cache
from resources.lib.ui import items
from resources.lib.yle_areena import constants as C

PAGE_SIZE = C.DEFAULT_PAGE_SIZE


def show_categories(handle: int, params: dict) -> None:
    entries = [
        items.folder_item(name, action="view", id=view_id)
        for name, view_id in C.TV_CATEGORIES
    ]
    xbmcplugin.setContent(handle, "videos")
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)


def show_view(handle: int, params: dict) -> None:
    """A category page / front page: list its rows (carousels) as folders."""
    view_id = params["id"]
    client = addon.build_client()
    ttl = addon.get_int("cache_ttl", 15) * 60

    def fetch():
        view = client.view(view_id)
        return [{"title": r.title, "source_uri": r.source_uri} for r in view.rows
                if r.source_uri and r.title]

    rows, stale = cache.get_or_fetch(f"view:{view_id}:{client.language}", ttl, fetch)
    if stale:
        _stale_notice()
    render_rows(handle, rows)


def render_rows(handle: int, rows) -> None:
    """Render a list of {title, source_uri} dicts as 'row' folders."""
    entries = [
        items.folder_item(r["title"], action="row", uri=r["source_uri"], title=r["title"])
        for r in rows
    ]
    xbmcplugin.setContent(handle, "videos")
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def show_row(handle: int, params: dict) -> None:
    """The cards of one row/package (paginated)."""
    uri = params["uri"]
    offset = addon.safe_int(params.get("offset"), 0)
    client = addon.build_client()
    page = client.list_content(uri, offset=offset, limit=PAGE_SIZE)
    _render_cards(handle, page, params, action="row", uri=params["uri"],
                  title=params.get("title"))


def show_series(handle: int, params: dict) -> None:
    """A series: one folder per season, or straight to episodes if single."""
    series_id = params["id"]
    client = addon.build_client()
    ttl = 60 * 60

    def fetch():
        s = client.series(series_id)
        return {"title": s.title,
                "seasons": [{"number": x.number, "title": x.title,
                             "playlist_url": x.playlist_url} for x in s.seasons]}

    data, stale = cache.get_or_fetch(f"series:{series_id}:{client.language}", ttl, fetch)
    if stale:
        _stale_notice()
    seasons = data["seasons"]
    if not seasons:
        xbmcplugin.endOfDirectory(handle)
        return
    if len(seasons) == 1:
        params = dict(params, url=seasons[0]["playlist_url"],
                      tvshowtitle=data.get("title") or "")
        show_episodes(handle, params)
        return
    entries = [
        items.folder_item(s["title"], action="episodes", url=s["playlist_url"],
                          tvshowtitle=data.get("title") or "", season=s["number"])
        for s in seasons
    ]
    xbmcplugin.setContent(handle, "seasons")
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)


def show_episodes(handle: int, params: dict) -> None:
    url = params["url"]
    offset = addon.safe_int(params.get("offset"), 0)
    client = addon.build_client()
    page = client.episodes(url, offset=offset, limit=PAGE_SIZE)
    _render_cards(handle, page, params, action="episodes", url=url,
                  tvshowtitle=params.get("tvshowtitle"),
                  container="episodes", season=params.get("season"))


def _render_cards(handle: int, page, params: dict, container: str = None, **next_params) -> None:
    container = container or next_params.pop("container", None) or _container_for(page)
    tvshowtitle = next_params.get("tvshowtitle")
    # read (don't pop) so the season is carried into the Next-page URL too
    season = next_params.get("season")
    entries = []
    for card in page:
        if season is not None and card.season is None:
            card.season = addon.safe_int(season, None)
        item = items.card_item(card, tvshowtitle=tvshowtitle, container=container)
        if item is not None:
            entries.append(item)
    if page.has_more:
        entries.append(items.next_page_item(page, **{k: v for k, v in next_params.items()
                                                     if v is not None}))
    xbmcplugin.setContent(handle, container)
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(handle)


def _container_for(page) -> str:
    types = {c.type for c in page}
    if types == {"series"}:
        return "tvshows"
    return "videos"


def _stale_notice() -> None:
    import xbmcgui
    xbmcgui.Dialog().notification(addon.ADDON_NAME, addon.localized(30204),
                                  xbmcgui.NOTIFICATION_INFO, 3000)
