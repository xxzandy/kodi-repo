"""Live TV: linear channels with now/next EPG + live events from /suorat."""
from datetime import datetime, timezone

import xbmcplugin

from resources.lib import addon, cache
from resources.lib.ui import catalog, items
from resources.lib.yle_areena.models import parse_iso, schedule_now_index


def live_menu(handle: int, params: dict) -> None:
    client = addon.build_client()

    def fetch():
        result = []
        for ch in client.live_channels():
            entry = {"name": ch["name"], "program_id": ch["program_id"], "now_next": ""}
            try:
                stream = client.get_stream(ch["program_id"])
                try:
                    client.enrich_schedule_titles(stream)
                except Exception as e:  # noqa: BLE001 - titles are best-effort
                    addon.log(f"EPG titles failed for {ch['program_id']}: {e}")
                entry["now_next"] = _now_next_text(stream.schedule)
            except Exception as e:  # noqa: BLE001 - EPG is best-effort
                addon.log(f"EPG fetch failed for {ch['program_id']}: {e}")
            result.append(entry)
        return result

    channels, _ = cache.get_or_fetch("live_epg", 300, fetch)

    entries = [
        items.live_channel_item(ch["name"], ch["program_id"], ch["now_next"])
        for ch in channels
    ]
    entries.append(items.folder_item(addon.localized(30110), action="live_events"))
    xbmcplugin.setContent(handle, "videos")
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def live_events(handle: int, params: dict) -> None:
    """Rows of areena.yle.fi/suorat, scraped fresh (pre-signed tokens current)."""
    client = addon.build_client()

    def fetch():
        view = client.live_events_rows()
        return [{"title": r.title, "source_uri": r.source_uri}
                for r in view.rows if r.source_uri and r.title]

    rows, _ = cache.get_or_fetch("suorat_rows", 300, fetch)
    catalog.render_rows(handle, rows)


def _now_next_text(schedule) -> str:
    """'Now: X (12:00-13:00)\nNext: Y' from a service_schedule entry list."""
    if not schedule:
        return ""
    current_idx = schedule_now_index(schedule, datetime.now(timezone.utc))
    lines = []
    if current_idx is not None:
        cur = schedule[current_idx]
        lines.append(f"{addon.localized(30111)}: {cur.title or '?'} "
                     f"({_hhmm(cur.start)}–{_hhmm(cur.end)})")
        if current_idx + 1 < len(schedule):
            nxt = schedule[current_idx + 1]
            lines.append(f"{addon.localized(30112)}: {nxt.title or '?'} "
                         f"({_hhmm(nxt.start)})")
    elif schedule:
        first = schedule[0]
        lines.append(f"{addon.localized(30112)}: {first.title or '?'} ({_hhmm(first.start)})")
    return "\n".join(lines)


def _hhmm(iso_ts) -> str:
    # Yle timestamps carry an offset (e.g. ...T18:00:00+03:00); convert to the
    # box's local time so displayed times match the viewer's clock.
    dt = parse_iso(iso_ts)
    return dt.astimezone().strftime("%H:%M") if dt else "?"
