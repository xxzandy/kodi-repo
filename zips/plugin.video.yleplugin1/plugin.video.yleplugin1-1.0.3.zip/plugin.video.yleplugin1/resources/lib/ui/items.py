"""Build rich Kodi ListItems from yle_areena models."""
import sys
from urllib.parse import urlencode

import xbmcgui

from resources.lib import addon
from resources.lib.yle_areena import images

PLUGIN_BASE = f"plugin://{addon.ADDON_ID}/"


def plugin_url(**params) -> str:
    return PLUGIN_BASE + "?" + urlencode({k: v for k, v in params.items() if v is not None})


def folder_item(label: str, *, art: dict = None, plot: str = None, **url_params):
    """A generic folder entry -> (url, ListItem, isFolder=True)."""
    li = xbmcgui.ListItem(label=label, offscreen=True)
    li.setArt(art or {"icon": addon.ICON, "fanart": addon.FANART})
    if plot:
        li.getVideoInfoTag().setPlot(plot)
    return plugin_url(**url_params), li, True


def card_item(card, *, tvshowtitle: str = None, container: str = "videos"):
    """A Card -> (url, ListItem, isFolder). Rich art + InfoTagVideo metadata."""
    li = xbmcgui.ListItem(label=card.title, offscreen=True)

    art = {}
    if card.image_id:
        art["thumb"] = images.thumb_url(card.image_id, card.image_version)
        art["landscape"] = images.landscape_url(card.image_id, card.image_version)
        art["poster"] = images.poster_url(card.image_id, card.image_version)
        art["fanart"] = images.fanart_url(card.image_id, card.image_version)
    else:
        art["icon"] = addon.ICON
        art["fanart"] = addon.FANART
    li.setArt(art)

    tag = li.getVideoInfoTag()
    if card.is_series:
        tag.setMediaType("tvshow")
    elif container == "episodes" and card.episode is not None:
        tag.setMediaType("episode")
    elif container == "movies":
        tag.setMediaType("movie")
    else:
        tag.setMediaType("video")
    tag.setTitle(card.title)
    if card.description:
        tag.setPlot(card.description)
    if card.duration_seconds:
        tag.setDuration(card.duration_seconds)
    if card.season is not None:
        tag.setSeason(card.season)
    if card.episode is not None:
        tag.setEpisode(card.episode)
    if tvshowtitle:
        tag.setTvShowTitle(tvshowtitle)
    if card.release_date and len(card.release_date) == 10 and card.release_date[4] == "-":
        tag.setFirstAired(card.release_date)
        try:
            tag.setYear(int(card.release_date[:4]))
        except ValueError:
            pass

    if not card.id:
        # No resolvable id -> nothing to browse or play; skip it.
        addon.log(f"skipping card without id: {card.title!r}")
        return None

    if card.is_folder:
        pointer_uri = (card.raw.get("pointer") or {}).get("uri", "")
        if "/packages/" in pointer_uri:
            # Package pointers are category views (rows of carousels),
            # e.g. yleareena://packages/57-1B1zANk3N == "Uutiset" category.
            return plugin_url(action="view", id=card.id), li, True
        # Series pages live at areena.yle.fi/<id>; their tabs hold playlists.
        return plugin_url(action="series", id=card.id), li, True

    li.setProperty("IsPlayable", "true")
    url = plugin_url(action="play", id=card.id, kind="vod")
    return url, li, False


def next_page_item(page, **url_params):
    """'Next page' entry carrying the next offset."""
    total_pages = -(-page.count // max(page.limit, 1))
    current = page.offset // max(page.limit, 1) + 1
    label = addon.localized(30220).format(current + 1, total_pages)  # "Next page (n/m)"
    li = xbmcgui.ListItem(label=f"[B]{label}[/B]", offscreen=True)
    li.setArt({"icon": "DefaultFolder.png"})
    li.setProperty("SpecialSort", "bottom")
    url_params["offset"] = page.next_offset
    return plugin_url(**url_params), li, True


def live_channel_item(name: str, program_id: str, now_next: str = "", logo: str = None):
    li = xbmcgui.ListItem(label=name, offscreen=True)
    tag = li.getVideoInfoTag()
    tag.setMediaType("video")
    tag.setTitle(name)
    if now_next:
        tag.setPlot(now_next)
    li.setArt({"thumb": logo or addon.ICON, "icon": logo or addon.ICON,
               "fanart": addon.FANART})
    li.setProperty("IsPlayable", "true")
    return plugin_url(action="play", id=program_id, kind="live"), li, False


def radio_channel_item(name: str, program_id: str):
    li = xbmcgui.ListItem(label=name, offscreen=True)
    tag = li.getMusicInfoTag()
    tag.setTitle(name)
    tag.setArtist("Yle")
    li.setArt({"icon": addon.ICON, "thumb": addon.ICON, "fanart": addon.FANART})
    li.setProperty("IsPlayable", "true")
    return plugin_url(action="play", id=program_id, kind="audio"), li, False
