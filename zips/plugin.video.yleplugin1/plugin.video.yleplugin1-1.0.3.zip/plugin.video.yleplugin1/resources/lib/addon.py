"""Addon-wide singletons: settings access, paths, logging, client factory."""
import os

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
ICON = ADDON.getAddonInfo("icon")
FANART = ADDON.getAddonInfo("fanart")


def profile_path(*parts: str) -> str:
    """Path inside the addon_data dir; creates the directory tree."""
    path = os.path.join(PROFILE_DIR, *parts[:-1]) if len(parts) > 1 else PROFILE_DIR
    os.makedirs(path, exist_ok=True)
    return os.path.join(PROFILE_DIR, *parts)


def get_str(setting_id: str, default: str = "") -> str:
    value = ADDON.getSetting(setting_id)
    return value if value else default


def get_bool(setting_id: str, default: bool = False) -> bool:
    value = ADDON.getSetting(setting_id)
    if value == "":
        return default
    return value.lower() == "true"


def get_int(setting_id: str, default: int = 0) -> int:
    try:
        return int(float(ADDON.getSetting(setting_id)))
    except (TypeError, ValueError):
        return default


def safe_int(value, default: int = 0) -> int:
    """int() that tolerates None / non-numeric query params instead of raising."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def localized(string_id: int) -> str:
    return ADDON.getLocalizedString(string_id)


def log(msg: str, level: int = xbmc.LOGDEBUG) -> None:
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


def log_error(msg: str) -> None:
    log(msg, xbmc.LOGERROR)


def build_client():
    """A configured YleAreenaClient (one per plugin invocation)."""
    from resources.lib.yle_areena import YleAreenaClient

    return YleAreenaClient(
        language=get_str("language", "fi"),
        spoof_fi_ip=get_bool("geo_spoof", False),
    )
