"""Typed data models for Yle Areena responses."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional

from . import images


def iso_duration_to_seconds(s) -> Optional[int]:
    """Convert an ISO-8601 duration (e.g. 'PT1H28M14S', 'PT1832S') to seconds."""
    if not s or not isinstance(s, str):
        return None
    m = re.match(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)(?:\.\d+)?S)?$", s)
    if not m:
        return None
    h, mi, se = (int(x) if x else 0 for x in m.groups())
    return 3600 * h + 60 * mi + se


def parse_iso(iso_ts) -> Optional[datetime]:
    """Parse an ISO-8601 timestamp into an aware datetime (assume UTC if naive)."""
    if not iso_ts or not isinstance(iso_ts, str):
        return None
    try:
        dt = datetime.fromisoformat(iso_ts)
    except ValueError:
        return None
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)


def schedule_now_index(schedule, now: datetime) -> Optional[int]:
    """Index of the schedule entry airing at `now` (an aware datetime), or None.

    Compares aware datetimes, so it is correct regardless of the box's timezone
    and of the offset on Yle's schedule timestamps.
    """
    for i, entry in enumerate(schedule):
        start = parse_iso(entry.start)
        end = parse_iso(entry.end)
        if start and end and start <= now <= end:
            return i
    return None


def _label(labels, type_name, key="raw"):
    for label in labels or []:
        if label.get("type") == type_name and key in label:
            return label[key]
    return None


_SEASON_EP_RE = re.compile(r"K(?:ausi\s*)?(\d+)\s*,?\s*[JO](?:akso|sa)?\s*(\d+)", re.IGNORECASE)
_EPISODE_RE = re.compile(r"[Jj]akso\s*(\d+)")


@dataclass
class Card:
    """A content card (program, clip, series or package) as returned by the UI API."""
    id: Optional[str]                  # e.g. "1-4371930" (from pointer.uri)
    type: Optional[str]                # program | clip | series | package
    title: str
    description: Optional[str] = None
    image_id: Optional[str] = None
    image_version: Optional[str] = None
    duration_seconds: Optional[int] = None
    season: Optional[int] = None
    episode: Optional[int] = None
    release_date: Optional[str] = None  # e.g. "2024-05-01" or Finnish formatted text
    labels: list = field(default_factory=list)
    raw: dict = field(default_factory=dict, repr=False)

    @property
    def is_playable(self) -> bool:
        return self.type in ("program", "clip")

    @property
    def is_series(self) -> bool:
        return self.type == "series"

    @property
    def is_folder(self) -> bool:
        return self.type in ("series", "package")

    def thumbnail(self, width: int = 640) -> Optional[str]:
        if not self.image_id:
            return None
        return images.image_url(self.image_id, self.image_version, width=width)

    def poster(self) -> Optional[str]:
        return images.poster_url(self.image_id, self.image_version) if self.image_id else None

    def fanart(self) -> Optional[str]:
        return images.fanart_url(self.image_id, self.image_version) if self.image_id else None

    @classmethod
    def from_api(cls, item: dict) -> "Card":
        pointer = item.get("pointer", {}) or {}
        uri = pointer.get("uri") or ""
        pid = uri.rsplit("/", 1)[-1] if uri else _label(item.get("labels"), "itemId")
        image = item.get("image", {}) or {}
        labels = item.get("labels", []) or []
        dur = _label(labels, "duration") or _label(labels, "progress")
        title = item.get("title")
        if isinstance(title, dict):           # some endpoints return {"fin": ...}
            title = title.get("fin") or title.get("swe") or ""
        description = item.get("description") if isinstance(item.get("description"), str) else None

        # Season/episode: explicit labels first, then "K1, J5"-style generic
        # labels, then the title/description text.
        season = _int_or_none(_label(labels, "seasonNumber"))
        episode = _int_or_none(_label(labels, "episodeNumber"))
        if season is None or episode is None:
            for text in ([_label(labels, "generic", "formatted") or ""]
                         + [title or "", description or ""]):
                m = _SEASON_EP_RE.search(text)
                if m:
                    season = season if season is not None else int(m.group(1))
                    episode = episode if episode is not None else int(m.group(2))
                    break
        if episode is None:
            m = _EPISODE_RE.search(title or "")
            if m:
                episode = int(m.group(1))

        release = (_label(labels, "releaseDate")
                   or _label(labels, "releaseDate", "formatted"))

        return cls(
            id=pid,
            type=pointer.get("type"),
            title=title or "???",
            description=description,
            image_id=image.get("id"),
            image_version=image.get("version"),
            duration_seconds=iso_duration_to_seconds(dur),
            season=season,
            episode=episode,
            release_date=release,
            labels=labels,
            raw=item,
        )


def _int_or_none(value) -> Optional[int]:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


@dataclass
class ContentPage:
    """A page of cards plus pagination metadata (meta.count/offset/limit)."""
    items: List[Card]
    count: int = 0       # total results
    offset: int = 0
    limit: int = 0

    @property
    def has_more(self) -> bool:
        # limit must be positive, else next_offset can't advance (would loop).
        return self.limit > 0 and (self.offset + self.limit) < self.count

    @property
    def next_offset(self) -> int:
        return self.offset + self.limit

    def __iter__(self):
        return iter(self.items)

    def __len__(self):
        return len(self.items)


@dataclass
class Row:
    """One carousel/list within a view (category page)."""
    title: str
    source_uri: Optional[str]   # content-list URL; fetch with client.list_content()
    type: Optional[str] = None
    raw: dict = field(default_factory=dict, repr=False)


@dataclass
class View:
    """A category page / front page: an ordered list of rows."""
    id: str
    title: Optional[str]
    rows: List[Row]


@dataclass
class Season:
    number: int
    title: str
    playlist_url: str          # fetch episodes with client.episodes()


@dataclass
class Series:
    id: str
    title: Optional[str]
    seasons: List[Season]
    kind: str = "Jaksot"       # "Jaksot" (episodes) or "Klipit" (clips)

    @property
    def single_season(self) -> bool:
        return len(self.seasons) == 1


@dataclass
class Subtitle:
    url: Optional[str]
    language: Optional[str]    # 3-letter (fin/swe/eng/smi)
    kind: Optional[str] = None  # e.g. translation / hard-of-hearing


@dataclass
class ScheduleEntry:
    """One entry of a live channel's service_schedule (EPG)."""
    title: Optional[str]
    start: Optional[str]       # ISO timestamp string
    end: Optional[str]
    program_id: Optional[str] = None
    raw: dict = field(default_factory=dict, repr=False)


@dataclass
class Stream:
    """Result of resolving a program id via the preview API."""
    program_id: str
    status: str                # ondemand | live | event | pending | expired | not_allowed | unavailable
    title: Optional[str] = None
    description: Optional[str] = None
    manifest_url: Optional[str] = None      # tokenised HLS .m3u8 (or live HLS)
    media_url: Optional[str] = None         # direct download URL (e.g. 78- MP3 podcasts)
    media_id: Optional[str] = None
    region: Optional[str] = None            # Finland | World
    is_protected: bool = False              # token-gated flag (NOT Widevine; streams are clear HLS)
    content_type: Optional[str] = None      # VideoObject | AudioObject
    duration_seconds: Optional[int] = None
    subtitles: List[Subtitle] = field(default_factory=list)
    is_live: bool = False
    dvr_window_seconds: int = 0
    age_restriction: Optional[int] = None
    schedule: List[ScheduleEntry] = field(default_factory=list)
    image_id: Optional[str] = None
    image_version: Optional[str] = None
    raw: dict = field(default_factory=dict, repr=False)

    @property
    def is_playable(self) -> bool:
        return bool(self.manifest_url or self.media_url)

    @property
    def is_audio(self) -> bool:
        return (self.content_type == "AudioObject"
                or bool(self.media_id and self.media_id.startswith("78-")))

    @property
    def play_url(self) -> Optional[str]:
        """Direct media (MP3) is preferred for audio podcasts; manifests otherwise."""
        if self.is_audio and self.media_url:
            return self.media_url
        return self.manifest_url or self.media_url
