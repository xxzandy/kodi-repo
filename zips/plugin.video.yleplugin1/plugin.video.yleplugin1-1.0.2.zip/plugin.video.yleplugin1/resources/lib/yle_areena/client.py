"""A small, dependency-light client for the Yle Areena public APIs.

Covers: search, category/view browsing, series -> seasons -> episodes,
stream resolution (preview API), live TV + live events, live radio,
and region lookup. No Kodi imports — testable with plain pytest.

Ported from the user's `yletest` investigation repo. Key facts:
  * Catalog/search/listing works from any IP.
  * Stream playback rights are evaluated per request; a residential Finnish
    connection needs nothing. `spoof_fi_ip=True` adds X-Forwarded-For with a
    random Elisa residential IP (yle-dl's trick) for manifest fetches.
  * Streams are clear HLS (no Widevine). `is_content_protected` means
    token-gated (short-lived Akamai `hdnts` token) — resolve fresh at play time.
"""
from __future__ import annotations

import ipaddress
import json
import random
import re
import time
from typing import Dict, List, Optional
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

import requests

from . import constants as C
from .models import (
    Card, ContentPage, Row, View, Season, Series, Stream, Subtitle, ScheduleEntry,
)


class YleAreenaError(RuntimeError):
    """Base error: network/API failure with a human-usable message."""


class LayoutChangedError(YleAreenaError):
    """Areena's web layout changed; scraping assumptions no longer hold."""


class YleAreenaClient:
    def __init__(
        self,
        language: str = "fi",
        country: str = "FI",
        session: Optional[requests.Session] = None,
        spoof_fi_ip: bool = False,
        timeout: int = 20,
    ):
        self.language = language
        self.country = country
        self.spoof_fi_ip = spoof_fi_ip
        self.timeout = timeout
        self.session = session or requests.Session()
        self.session.headers.setdefault(
            "User-Agent",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        )

    # ------------------------------------------------------------------ #
    # low-level helpers
    # ------------------------------------------------------------------ #
    def _request(self, url: str, params: Optional[dict] = None,
                 headers: Optional[dict] = None) -> requests.Response:
        """GET with one retry on transient failures (5xx / timeout / connection)."""
        last_exc: Optional[Exception] = None
        for attempt in (0, 1):
            try:
                r = self.session.get(url, params=params, headers=headers, timeout=self.timeout)
                if r.status_code >= 500 and attempt == 0:
                    time.sleep(1.5)
                    continue
                r.raise_for_status()
                return r
            except (requests.Timeout, requests.ConnectionError) as e:
                last_exc = e
                if attempt == 0:
                    time.sleep(1.5)
                    continue
                raise YleAreenaError(f"Yle API unreachable: {e}") from e
            except requests.HTTPError:
                raise
        raise YleAreenaError(f"Yle API unreachable: {last_exc}")

    def _get(self, url: str, params: Optional[dict] = None,
             headers: Optional[dict] = None) -> dict:
        return self._request(url, params=params, headers=headers).json()

    def _ui_params(self, **extra) -> dict:
        p = {
            "client": C.CLIENT,
            "language": self.language,
            "v": C.API_VERSION,
            "country": self.country,
            "isPortabilityRegion": "true",
            "app_id": C.AREENA_APP_ID,
            "app_key": C.AREENA_APP_KEY,
        }
        p.update(extra)
        return p

    @staticmethod
    def _add_query(url: str, extra: Dict[str, str]) -> str:
        """Add/override query params on an existing (often pre-signed) URL."""
        p = urlparse(url)
        # keep_blank_values so blank-valued signature params on pre-signed
        # source URIs survive the round-trip.
        q = {k: v[0] for k, v in parse_qs(p.query, keep_blank_values=True).items()}
        q.update(extra)
        return urlunparse((p.scheme, p.netloc, p.path, "", urlencode(q), ""))

    def _next_data(self, page_url: str) -> dict:
        """Fetch an Areena SSR page and return its parsed __NEXT_DATA__ JSON."""
        html = self._request(page_url).text
        m = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.DOTALL)
        if not m:
            raise LayoutChangedError(f"__NEXT_DATA__ not found at {page_url}")
        return json.loads(m.group(1))

    @staticmethod
    def program_id(value: str) -> str:
        """Normalise 'yleareena://items/1-123', '.../1-123', or '1-123' -> '1-123'."""
        return value.rstrip("/").rsplit("/", 1)[-1]

    def random_fi_ip(self) -> str:
        net = ipaddress.ip_network(C.ELISA_IP_NETWORK)
        return str(ipaddress.ip_address(
            random.randint(int(net.network_address) + 1, int(net.broadcast_address) - 1)
        ))

    def manifest_headers(self) -> dict:
        """Headers to use when fetching a Stream.manifest_url (residential-IP spoof)."""
        return {"X-Forwarded-For": self.random_fi_ip()} if self.spoof_fi_ip else {}

    # ------------------------------------------------------------------ #
    # search
    # ------------------------------------------------------------------ #
    def search(self, query: str, *, offset: int = 0, limit: int = C.DEFAULT_PAGE_SIZE,
               service: str = "tv") -> ContentPage:
        data = self._get(f"{C.UI_API}/search", params=self._ui_params(
            query=query, service=service, episodes="true", packages="true",
            offset=offset, limit=limit,
        ))
        return self._content_page(data)

    # ------------------------------------------------------------------ #
    # categories / views / content lists
    # ------------------------------------------------------------------ #
    def categories(self) -> List[tuple]:
        """Static list of (name, view_id) TV categories. Browse with .view(view_id)."""
        return list(C.TV_CATEGORIES)

    def view(self, view_id: str = C.TV_FRONT_PAGE_VIEW) -> View:
        """A category page / front page -> its ordered rows (carousels)."""
        if view_id == C.TV_FRONT_PAGE_VIEW:
            page_url = f"{C.AREENA_WEB}/tv"
        else:
            page_url = f"{C.AREENA_WEB}/tv/ohjelmat/{view_id}"
        return self.view_from_url(page_url, view_id=view_id)

    def view_from_url(self, page_url: str, view_id: str = "") -> View:
        """Parse any Areena SSR page (front page, category, /suorat) into rows."""
        nd = self._next_data(page_url)
        view = nd.get("props", {}).get("pageProps", {}).get("view", {})
        tabs = view.get("tabs", []) or [{}]
        content = tabs[0].get("content", []) if tabs else []
        rows = [
            Row(
                title=r.get("title") or "",
                source_uri=(r.get("source") or {}).get("uri"),
                type=r.get("type"),
                raw=r,
            )
            for r in content
            if r.get("type") in ("list", "card", None) or (r.get("source"))
        ]
        return View(id=view_id or page_url, title=view.get("title"), rows=rows)

    def live_events_rows(self) -> View:
        """Rows of the 'suorat' (live events) page, scraped fresh at runtime."""
        return self.view_from_url(C.SUORAT_PAGE, view_id="suorat")

    def list_content(self, source_uri: str, *, offset: int = 0,
                     limit: int = C.DEFAULT_PAGE_SIZE) -> ContentPage:
        """Fetch the cards of a row/package given its (pre-signed) source URI."""
        url = self._add_query(source_uri, {
            "app_id": C.AREENA_APP_ID, "app_key": C.AREENA_APP_KEY,
            "offset": str(offset), "limit": str(min(limit, C.MAX_PAGE_SIZE)),
        })
        return self._content_page(self._get(url))

    # ------------------------------------------------------------------ #
    # series -> seasons -> episodes
    # ------------------------------------------------------------------ #
    def series(self, series_id: str) -> Series:
        """Resolve a series' seasons (and the playlist URL for each)."""
        series_id = self.program_id(series_id)
        nd = self._next_data(f"{C.AREENA_WEB}/{series_id}")
        view = nd.get("props", {}).get("pageProps", {}).get("view", {})
        tabs = view.get("tabs", [])
        ep_tab = next((t for t in tabs if t.get("title")
                       in ("Jaksot", "Klipit", "Avsnitt", "Klipp")), None)
        title = view.get("title")
        if not ep_tab or not ep_tab.get("content"):
            return Series(id=series_id, title=title, seasons=[], kind="Jaksot")
        block = ep_tab["content"][0]
        base = (block.get("source") or {}).get("uri")
        if not base:
            raise LayoutChangedError(f"series {series_id}: no playlist source uri")
        options = (block.get("filters") or [{}])[0].get("options", [])
        seasons: List[Season] = []
        if options:
            for i, opt in enumerate(options, start=1):
                m = re.match(r"^Kausi (\d+)$", opt.get("title", ""))
                num = int(m.group(1)) if m else i
                url = self._add_query(base, {k: str(v) for k, v in (opt.get("parameters") or {}).items()})
                seasons.append(Season(number=num, title=opt.get("title") or f"Kausi {num}", playlist_url=url))
        else:
            seasons.append(Season(number=1, title="Kausi 1", playlist_url=base))
        return Series(id=series_id, title=title, seasons=seasons, kind=ep_tab.get("title", "Jaksot"))

    def episodes(self, season_or_playlist_url, *, offset: int = 0,
                 limit: int = C.DEFAULT_PAGE_SIZE) -> ContentPage:
        """Fetch a page of episodes for a Season or a season playlist URL."""
        url = season_or_playlist_url.playlist_url if isinstance(season_or_playlist_url, Season) \
            else season_or_playlist_url
        limit = min(limit, C.MAX_PAGE_SIZE)
        url = self._add_query(url, {
            "app_id": C.AREENA_APP_ID, "app_key": C.AREENA_APP_KEY,
            "offset": str(offset), "limit": str(limit),
        })
        return self._content_page(self._get(url))

    # ------------------------------------------------------------------ #
    # live TV / radio channel lists
    # ------------------------------------------------------------------ #
    def live_channels(self) -> List[dict]:
        """The 3 linear TV channels: preview-API program ids + direct-HLS fallback."""
        return [
            {
                "name": name,
                "program_id": pid,
                "direct_url": C.LIVE_TV_MANIFEST.format(stream_id=sid, stream_name=sname),
            }
            for name, pid, sid, sname in C.LIVE_TV_CHANNELS
        ]

    def radio_channels(self) -> List[dict]:
        return [{"name": name, "program_id": pid} for name, pid in C.RADIO_CHANNELS]

    # ------------------------------------------------------------------ #
    # stream resolution (preview API)
    # ------------------------------------------------------------------ #
    def get_stream(self, program_id: str) -> Stream:
        """Resolve a program/clip id to a playable Stream via the preview API."""
        pid = self.program_id(program_id)
        params = {
            "app_id": C.PLAYER_APP_ID, "app_key": C.PLAYER_APP_KEY,
            "language": "fin" if self.language == "fi" else self.language,
            "ssl": "true", "countryCode": self.country, "host": "areena.yle.fi",
            "isMobile": "false", "isPortabilityRegion": "true",
        }
        headers = {"Referer": f"{C.AREENA_WEB}/tv", "Origin": C.AREENA_WEB}
        try:
            data = self._get(f"{C.PLAYER_API}/{pid}.json", params=params, headers=headers)
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                return Stream(program_id=pid, status="unavailable")
            raise YleAreenaError(f"preview API error for {pid}: {e}") from e
        return self._parse_preview(pid, data)

    @staticmethod
    def _parse_preview(pid: str, data: dict) -> Stream:
        d = data.get("data", {}) or {}
        # status keys, in priority order
        for key, status, is_live in (
            ("ongoing_ondemand", "ondemand", False),
            ("ongoing_channel", "live", True),
            ("ongoing_event", "event", True),
            ("pending_event", "pending", False),
            ("pending_ondemand", "pending", False),
            ("gone", "expired", False),
            ("not_allowed", "not_allowed", False),
        ):
            if key in d:
                o = d[key] or {}
                title = _pick_lang(o.get("title"))
                description = _pick_lang(o.get("description"))
                subs = [
                    Subtitle(url=s.get("uri"), language=s.get("language") or s.get("lang"),
                             kind=s.get("kind"))
                    for s in (o.get("subtitles") or [])
                ]
                dur = (o.get("duration") or {}).get("duration_in_seconds")
                rating = o.get("content_rating") or {}
                image = o.get("image") or {}
                schedule = [
                    ScheduleEntry(
                        title=_pick_lang((e.get("title") if isinstance(e, dict) else None)),
                        start=(e.get("start_time") or e.get("startTime") or e.get("start")
                               if isinstance(e, dict) else None),
                        end=(e.get("end_time") or e.get("endTime") or e.get("end")
                             if isinstance(e, dict) else None),
                        program_id=(e.get("program_id") or e.get("programId")
                                    if isinstance(e, dict) else None),
                        raw=e if isinstance(e, dict) else {},
                    )
                    for e in (o.get("service_schedule") or [])
                ]
                return Stream(
                    program_id=pid, status=status, title=title, description=description,
                    manifest_url=o.get("manifest_url"),
                    media_url=o.get("media_url"),
                    media_id=o.get("media_id"), region=o.get("region"),
                    is_protected=bool(o.get("is_content_protected")),
                    content_type=o.get("content_type"),
                    duration_seconds=dur, subtitles=subs, is_live=is_live,
                    dvr_window_seconds=o.get("dvr_window_in_seconds", 0) or 0,
                    age_restriction=rating.get("age_restriction"),
                    schedule=schedule,
                    image_id=image.get("id"), image_version=image.get("version"),
                    raw=o,
                )
        return Stream(program_id=pid, status="unavailable")

    # ------------------------------------------------------------------ #
    # region
    # ------------------------------------------------------------------ #
    def current_region(self) -> dict:
        """What region Yle thinks the *caller* is in (affects stream rights)."""
        return self._get(C.LOCATIONS_API, params={
            "app_id": C.PLAYER_APP_ID, "app_key": C.PLAYER_APP_KEY,
        })

    # ------------------------------------------------------------------ #
    # shared parsing
    # ------------------------------------------------------------------ #
    @staticmethod
    def _content_page(data: dict) -> ContentPage:
        meta = data.get("meta", {}) or {}
        items = [Card.from_api(it) for it in data.get("data", []) or []
                 if isinstance(it, dict) and it.get("type") == "card"]
        return ContentPage(
            items=items,
            count=meta.get("count", len(items)) or 0,
            offset=meta.get("offset", 0) or 0,
            limit=meta.get("limit", len(items)) or 0,
        )


def _pick_lang(value, preferred=("fin", "swe")):
    """Yle returns some texts as {'fin': ..., 'swe': ...} dicts, others as str."""
    if isinstance(value, dict):
        for lang in preferred:
            if value.get(lang):
                return value[lang]
        return next((v for v in value.values() if v), None)
    return value
